Name: Window Switcher
Author: Adrian Scripca
Email: benishor@gmail.com
Link: http://hq.scene.ro/blog/read/notepadplusplus_window_switcher_plugin/

This is the initial version of the "Window Switcher" Notepad++ plugin.

What does it do
    * allows window switching bound to a shortcut ( default shortcuts ALT+1 ... ALT+0 )
    * opens corresponding h/c/cpp file through the means of a shortcut ( default shortcut ALT+O )

How to install

   1. copy the plugin corresponding to your Notepad++ version into the Notepad++\plugins directory ( NppWindowSwitcherAnsi.dll for ANSI version, NppWindowSwitcherUnicode.dll for UNICODE )
   2. configure the shortcuts
   3. if you want to use the default shortcuts, be aware of the fact that ALT+1 .. ALT+8 are bound by default to "collapse current level". Go to Settings -> Shortcut mapper -> Main Menu and change the shortcuts so they point to something else ( I remaped them to Ctrl+Alt+1 ... Ctrl+Alt+8 )
   4. enjoy
